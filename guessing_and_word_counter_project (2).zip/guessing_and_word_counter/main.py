"""
Number Guessing Game and Word Frequency Counter
Python 3.10+
Run: python main.py
"""

import random
import string
from collections import Counter

LOWER_LIMIT = 1
UPPER_LIMIT = 100
MAX_ATTEMPTS = 7
STARTING_SCORE = 100
POINTS_LOST_PER_WRONG_GUESS = 10


def read_integer(prompt, minimum=None, maximum=None):
    """Read and validate a whole number, optionally within a range."""
    while True:
        value = input(prompt).strip()

        try:
            number = int(value)
        except ValueError:
            print("Please enter a whole number.")
            continue

        if minimum is not None and number < minimum:
            print(f"Please enter a number of at least {minimum}.")
            continue
        if maximum is not None and number > maximum:
            print(f"Please enter a number no greater than {maximum}.")
            continue

        return number


def play_round():
    """Play one round and return the score earned (zero if not won)."""
    secret_number = random.randint(LOWER_LIMIT, UPPER_LIMIT)
    attempts_used = 0
    score = STARTING_SCORE

    print(f"\nI'm thinking of a number from {LOWER_LIMIT} to {UPPER_LIMIT}.")
    print(f"You have {MAX_ATTEMPTS} valid guesses.")

    while attempts_used < MAX_ATTEMPTS:
        guess = read_integer(
            f"Guess {attempts_used + 1}/{MAX_ATTEMPTS}: ",
            LOWER_LIMIT,
            UPPER_LIMIT,
        )
        attempts_used += 1

        if guess == secret_number:
            print(f"Correct! You guessed it in {attempts_used} attempt(s).")
            print(f"Your score: {score}")
            return score
        elif guess < secret_number:
            print("Too low!")
        else:
            print("Too high!")

        score = max(0, score - POINTS_LOST_PER_WRONG_GUESS)

        if attempts_used < MAX_ATTEMPTS:
            print(f"Current possible score: {score}")

    print(f"\nNo attempts left. The number was {secret_number}.")
    print("Your score: 0")
    return 0


def guessing_game(best_score):
    """Run rounds until the player chooses not to replay."""
    while True:
        round_score = play_round()
        if round_score > best_score:
            best_score = round_score
            print("New best score!")

        print(f"Best score this session: {best_score}")
        again = input("Play again? (y/n): ").strip().lower()
        while again not in ("y", "yes", "n", "no"):
            again = input("Please enter y or n: ").strip().lower()

        if again in ("n", "no"):
            break

    return best_score


def count_words(file_path):
    """Read a UTF-8 text file and return its word-frequency Counter."""
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            text = file.read()
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        print("Place the text file in this project folder or enter its path.")
        return None
    except UnicodeDecodeError:
        print("The file could not be read as UTF-8 text.")
        return None
    except OSError as error:
        print(f"Could not read the file: {error}")
        return None

    cleaned_text = text.lower().translate(
        str.maketrans("", "", string.punctuation)
    )
    words = cleaned_text.split()
    return Counter(words)


def word_counter():
    """Ask for a file and display its ten most frequent words."""
    print("\n--- Word Frequency Counter ---")
    file_path = input("Enter text file path [sample.txt]: ").strip()
    if not file_path:
        file_path = "sample.txt"

    counts = count_words(file_path)
    if counts is None:
        return

    total_words = sum(counts.values())
    unique_words = len(counts)

    print(f"\nTotal words:  {total_words}")
    print(f"Unique words: {unique_words}")

    if total_words == 0:
        print("The file is empty or contains no words.")
        return

    print("\nTop 10 words")
    print("-" * 22)
    print(f"{'Word':<15}{'Count':>7}")
    print("-" * 22)

    for word, frequency in counts.most_common(10):
        print(f"{word:<15}{frequency:>7}")


def main():
    """Display the application menu until the user chooses Quit."""
    best_score = 0

    while True:
        print("\n========== MAIN MENU ==========")
        print("1. Play the Number Guessing Game")
        print("2. Count Words in a Text File")
        print("3. Quit")

        choice = input("Choose an option (1-3): ").strip()

        if choice == "1":
            best_score = guessing_game(best_score)
        elif choice == "2":
            word_counter()
        elif choice == "3":
            print("Thanks for using the program. Goodbye!")
            break
        else:
            print("Invalid choice. Please select 1, 2, or 3.")


if __name__ == "__main__":
    main()
